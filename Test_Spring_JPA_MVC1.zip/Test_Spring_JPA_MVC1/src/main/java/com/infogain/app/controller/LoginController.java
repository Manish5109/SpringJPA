package com.infogain.app.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



@Controller
public class LoginController {

	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(ModelMap map) {
		return "home";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(ModelMap map) {
		return "home";
	}
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String loginPost(ModelMap map) {
		return "home";
	}
	
	@RequestMapping(value = "/loginPage", method = RequestMethod.POST)
	public String loginpage(ModelMap map) {
		return "login";
	}
	
	
	
	@RequestMapping(value = "/loginValidation", method = RequestMethod.POST)
	public String loginValidation(HttpServletRequest request, HttpServletResponse response) {
		boolean loginStatus = false;
		//loginStatus = loginService.loginProcess(request.getParameter("uname"), request.getParameter("pwd"));
		if (loginStatus == true) {
			HttpSession httpSession = request.getSession();
			httpSession.setAttribute("loginStatus", "true");
			httpSession.setAttribute("username", request.getParameter("uname"));
			return "welcome";
		} else {
			return "error";
		}
	}
}
