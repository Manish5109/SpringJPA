package com.infogain.app.service;

import java.util.List;

import com.infogain.app.entity.Registration;

public class RegistrationServiceIMPL implements RegistrationService{

	@Override
	public void saveRegistration(Registration rgs) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteRegistration(String empId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateRegistration(String empId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Registration> getRegistration() {
		// TODO Auto-generated method stub
		return null;
	}

}
