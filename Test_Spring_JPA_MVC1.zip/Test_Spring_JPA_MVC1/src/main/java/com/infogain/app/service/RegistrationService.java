package com.infogain.app.service;

import java.util.List;

import com.infogain.app.entity.Registration;

public interface RegistrationService {
	
	public void saveRegistration(Registration rgs);
	public void deleteRegistration(String empId);
	public void updateRegistration(String empId);
	public List<Registration> getRegistration();

}
