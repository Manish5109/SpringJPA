package com.infogain.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.infogain.app.repository")
@EntityScan(basePackages = "com.infogain.app.entity")
@ComponentScan(basePackages = "com.infogain.app.controller")
public class TestSpringJpaMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestSpringJpaMvcApplication.class, args);
	}
}
