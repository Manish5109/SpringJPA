package com.infogain.app.repository;

import org.springframework.data.repository.CrudRepository;


import com.infogain.app.entity.Registration;

public interface RegistrationRepository extends CrudRepository<Registration, Long> {

	public Registration findByUserName(String username);
}
